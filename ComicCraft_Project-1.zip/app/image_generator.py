import os
from pathlib import Path
from PIL import Image,ImageDraw
import requests
DIR=Path(__file__).parent/"static"/"generated"; DIR.mkdir(parents=True,exist_ok=True)
def generate_image(prompt,n):
    token=os.getenv("HF_API_KEY")
    if token:
        url="https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0"
        r=requests.post(url,headers={"Authorization":f"Bearer {token}"},data=prompt.encode(),timeout=120)
        if r.ok and r.headers.get("content-type","").startswith("image"):
            (DIR/f"panel_{n}.png").write_bytes(r.content)
            return f"/static/generated/panel_{n}.png"
    im=Image.new("RGB",(900,600),(235,232,220)); d=ImageDraw.Draw(im)
    d.rectangle((15,15,885,585),outline=(30,35,45),width=8)
    d.text((45,45),f"COMIC PANEL {n}",fill=(30,35,45))
    d.ellipse((380,150,520,290),fill=(245,210,170),outline=(30,35,45),width=5)
    d.rectangle((350,285,550,455),fill=(75,115,165),outline=(30,35,45),width=5)
    d.rectangle((80,470,820,550),fill="white",outline=(30,35,45),width=3)
    d.text((105,495),prompt[:75],fill=(30,35,45))
    im.save(DIR/f"panel_{n}.png")
    return f"/static/generated/panel_{n}.png"
