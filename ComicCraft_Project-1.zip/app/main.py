import os, json
from pathlib import Path
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from .gemini_flash import generate_outline
from .gemini_pro import generate_story
from .image_generator import generate_image
from .exporters import save_pdf

BASE=Path(__file__).parent
STATIC=BASE/"static"; (STATIC/"generated").mkdir(parents=True,exist_ok=True); (STATIC/"exports").mkdir(parents=True,exist_ok=True)
app=FastAPI(title="ComicCraft - AI Comic Story Creator")
app.mount("/static",StaticFiles(directory=STATIC),name="static")
templates=Jinja2Templates(directory=BASE/"templates")

@app.get("/",response_class=HTMLResponse)
async def home(request:Request):
    return templates.TemplateResponse("index.html",{"request":request})

@app.post("/generate",response_class=HTMLResponse)
async def generate(request:Request,prompt:str=Form(...),character:str=Form(...),setting:str=Form(...),tone:str=Form(...),art_style:str=Form(...)):
    try:
        outline=generate_outline(prompt,character,setting,tone,art_style)
        story=generate_story(outline,prompt,character,setting,tone,art_style)
        for i,panel in enumerate(story["panels"],1):
            panel["image_url"]=generate_image(panel.get("image_prompt",panel.get("scene_description","")),i)
        comic={**story,"prompt":prompt,"character":character,"setting":setting,"tone":tone,"art_style":art_style}
        return templates.TemplateResponse("comic_preview.html",{"request":request,"comic":comic})
    except Exception as e:
        return templates.TemplateResponse("index.html",{"request":request,"error":str(e)})

@app.post("/generate-comic/json")
async def generate_json(data:dict):
    outline=generate_outline(data.get("prompt",""),data.get("character",""),data.get("setting",""),data.get("tone",""),data.get("art_style",""))
    story=generate_story(outline,data.get("prompt",""),data.get("character",""),data.get("setting",""),data.get("tone",""),data.get("art_style",""))
    return JSONResponse({"outline":outline,"story":story})

@app.get("/test-image")
async def test_image():
    return {"image":generate_image("comic book test panel",999)}

@app.post("/export-success")
async def export(data:dict):
    path=save_pdf(data)
    return {"download":f"/download/{Path(path).name}"}

@app.get("/download/{filename}")
async def download(filename:str):
    path=STATIC/"exports"/filename
    return FileResponse(path,media_type="application/pdf",filename=filename)
