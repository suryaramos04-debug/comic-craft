import os,json,re
import google.generativeai as genai
def generate_outline(prompt,character,setting,tone,art_style):
    key=os.getenv("GEMINI_API_KEY")
    if not key: raise RuntimeError("Add GEMINI_API_KEY to .env")
    genai.configure(api_key=key)
    model=genai.GenerativeModel("gemini-1.5-flash")
    q=f'''Create a 5-panel comic outline. Prompt:{prompt}; Character:{character}; Setting:{setting}; Tone:{tone}; Art style:{art_style}. Return ONLY JSON with title and panels, each containing panel and scene.'''
    t=model.generate_content(q).text.strip()
    t=re.sub(r"^```json\s*|\s*```$","",t)
    return json.loads(t)
