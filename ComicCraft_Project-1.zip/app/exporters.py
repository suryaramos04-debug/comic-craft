from pathlib import Path
from fpdf import FPDF
BASE=Path(__file__).parent
OUT=BASE/"static"/"exports"; OUT.mkdir(parents=True,exist_ok=True)
def save_pdf(comic):
    path=OUT/"comiccraft_comic.pdf"; pdf=FPDF()
    for i,p in enumerate(comic.get("panels",[]),1):
        pdf.add_page(); pdf.set_font("Helvetica","B",18); pdf.cell(0,12,f"Panel {i}: {p.get('title','')}",ln=True)
        img=BASE/"static"/p.get("image_url","").replace("/static/","")
        if img.exists(): pdf.image(str(img),x=15,y=35,w=180)
        pdf.set_y(145); pdf.set_font("Helvetica","",12)
        for k in ["scene_description","caption","narration","dialogue"]:
            if p.get(k): pdf.multi_cell(0,8,f"{k.replace('_',' ').title()}: {p[k]}"); pdf.ln(2)
    pdf.output(str(path)); return path
