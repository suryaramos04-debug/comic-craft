import os,json,re
import google.generativeai as genai
def generate_story(outline,prompt,character,setting,tone,art_style):
    key=os.getenv("GEMINI_API_KEY")
    if not key: raise RuntimeError("Add GEMINI_API_KEY to .env")
    genai.configure(api_key=key)
    model=genai.GenerativeModel("gemini-1.5-pro")
    q=f'''Turn this outline into a 5-panel comic. Outline:{json.dumps(outline)}. Character:{character}; Setting:{setting}; Tone:{tone}; Art style:{art_style}; Prompt:{prompt}. Return ONLY JSON with title and panels. Each panel must contain panel,title,scene_description,caption,narration,dialogue,image_prompt.'''
    t=model.generate_content(q).text.strip()
    t=re.sub(r"^```json\s*|\s*```$","",t)
    return json.loads(t)
