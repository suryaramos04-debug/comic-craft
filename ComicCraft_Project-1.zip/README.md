# ComicCraft — AI Comic Story Creator

Run:
1. `python -m venv venv`
2. Windows: `venv\Scripts\activate`
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and add `GEMINI_API_KEY`.
5. `uvicorn app.main:app --reload`
6. Open `http://127.0.0.1:8000`

The project follows the supplied ComicCraft document: FastAPI + Jinja2, Gemini Flash for a 5-panel outline, Gemini Pro for narration/dialogue, image generation, comic preview and PDF export.
